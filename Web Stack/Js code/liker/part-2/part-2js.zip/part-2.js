var count=0;
var el =document.querySelector(".para")
function likeplus(){
    count++;
    el.innerText= count+"Like(s)";
}

var count=0;
var il =document.querySelector(".para1")
function likeplus1(){
    count++;
    il.innerText= count+"Like(s)";
}
var count=0;
var al =document.querySelector(".para2")
function likeplus2(){
    count++;
    al.innerText= count+"Like(s)";
}