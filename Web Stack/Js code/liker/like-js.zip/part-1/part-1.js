var count=0;
var el =document.querySelector(".para")
function likeplus(){
    count++;
    el.innerText= count+"Like(s)";
}