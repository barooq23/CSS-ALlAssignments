public class Mammal {
    int energyLevel =300;


    void displayEnergy(){
        System.out.println("Energy level = " + energyLevel);
    }

}