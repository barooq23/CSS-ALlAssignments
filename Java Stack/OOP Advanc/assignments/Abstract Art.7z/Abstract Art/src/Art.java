public abstract class Art {
    private String title;
    private String author;
    private String description;

    public abstract void viewArt();

}
