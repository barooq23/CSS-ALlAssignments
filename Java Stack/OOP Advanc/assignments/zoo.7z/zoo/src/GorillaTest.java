public class GorillaTest {

	public static void main(String[] args) {
		
		Gorilla animl = new Gorilla();
		animl.throwSomething();
		animl.throwSomething();
		animl.throwSomething();
		animl.eatBananas();
		animl.eatBananas();
		animl.climb();

	}

}
