package com.laith.loginandregistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAndLoginApplicationTestsUser {

    @Test
    void contextLoads() {
    }
}
