package models;

public class Travel {
}
