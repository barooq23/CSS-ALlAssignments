package com.laith.booksapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksAPiApplicationTests {

    @Test
    void contextLoads() {
    }
}
